﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Kraj
    {
        private string nazwa;
        private int powierzchnia;
        public Kraj(string nazwa,int powierzchnia)
        {
            this.nazwa = nazwa;
            this.powierzchnia = powierzchnia;
        }
        /*static Kraj UtworzKraj(string nazwa,int powierzchnia)
        {
            this.nazwa = nazwa;
            this.powierzchnia = powierzchnia;
        }*/
        /*public int CompareTo(Kraj obj)
        {
            if (obj == null) return 1;
        }*/
        public override string ToString()
        {
            return "Kraj: " + nazwa.ToString() + ", Powierzchnia:" + powierzchnia.ToString();
        }
    }
    class Stolica
    {
        private string nazwa;
        private bool lotnisko;
        public Stolica(string nazwa,bool lotnisko)
        {
            this.nazwa = nazwa;
            this.lotnisko = lotnisko;
        }
        public override string ToString()
        {
            return "Stolica: " + nazwa.ToString() + ", Lotnisko: " + lotnisko.ToString();
        }
    }
    interface IOperacje
    {
        void Dodaj();
        void Usun();
        void Usun(string nazwa);
    }
    interface ISprawdzanie : IOperacje
    {
        bool Sprawdz(string nazwa);
    }
    class Europa 
    {
        private SortedList<Kraj, Stolica> panstwa;
        private Kraj kraj;
        private Stolica stolica;

        public void Dodaj(string nazwaKraj,int powierzchnia,string nazwaStolica,bool lotnisko)
        {
            this.kraj = new Kraj(nazwaKraj,powierzchnia);
            this.stolica = new Stolica(nazwaStolica,lotnisko);
            panstwa = new SortedList<Kraj, Stolica>();
            panstwa.Add(kraj,stolica);
        }
        public void Usun()
        {
            panstwa.Remove(panstwa.Last().Key);
        }
        public string Kraje()
        {
            return panstwa.ToString();
        }
        /*public void Usun(string nazwaKraj)
        {
            if(nazwaKraj == Kraj.nazwa)
            panstwa.Remove(nazwaKraj);
        }*/
        /*public string Kraje()
        {
            foreach (KeyValuePair<string> kvp in panstwa)
            {
                Console.WriteLine(kvp.Value);
            }
        }*/
    }
    class Program
    {
        static void Main(string[] args)
        {
            Europa eu = new Europa();

            Console.WriteLine("Co chcesz zrobić?");
            Console.WriteLine("A - dodaj pozycję");
            Console.WriteLine("B - usuń pozycję");
            Console.WriteLine("C - pokaż kraje");
            Console.WriteLine("D - pokaż stolice");
            Console.WriteLine("E - sprawdź");
            Console.WriteLine("X - wyjście z aplikacji");
            
            string com = Console.ReadLine();

            switch (com)
            {
                case "A":
                    Console.Clear();
                    Console.Write("Podaj nazwę Państwa w Europie: ");
                    string name = Console.ReadLine();
                    Console.Write(" Podaj powierzchnie:");
                    string pow = Console.ReadLine();
                    int powint = Int32.Parse(pow);
                    Console.Write(" Podaj stolicę:");
                    string st = Console.ReadLine();
                    /*Console.Write(" Wpisz true jesli lotnisko dziala, false jesli nie:");
                    bool lot = Console.Read();*/

                    eu.Dodaj(name,powint,st,true);
                    break;
                case "B":
                    eu.Usun();
                    break;
                case "C":
                    Console.WriteLine(eu.Kraje());
                    break;
                case "D":
                    break;
                case "E":
                    break;
                case "X":

                    break;

            }



            

            Console.ReadKey();
        }
    }
}
